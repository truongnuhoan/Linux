print 'nhap ban kinh hinh tron: \n'
r = input ('ban kinh =')
print '\n chu vi hinh tron:',2*r*3.14
print '\n dien tich hinh tron',r*r*3.14
