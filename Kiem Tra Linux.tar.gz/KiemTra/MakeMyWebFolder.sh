mkdir -p Myweb/images/icon
mkdir -p Myweb/images/background
mkdir -p Myweb/images/animation
mkdir -p Myweb/databases
mkdir -p Myweb/scripts
mkdir -p Myweb/java
