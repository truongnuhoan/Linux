import math
print 'nhap vao toa do 2 diem: \n'
print 'nhap toa do diem A: \n'
xA = input ('xA = ')
yA = input ('yA = ')
zA = input ('zA = ')
print '\n nhap toa do diem B: \n'
xB = input ('xB = ')
yB = input ('yB = ')
zB = input ('zB = ')
print '\n khoang canh euclidean giua hai diem A va B:',math.sqrt( (xB - xA)**2 + (yB - yA)**2 + (zB - zA)**2)

